![Business / Corporate Websites Design ](https://user-images.githubusercontent.com/23438431/84922993-36259780-b0f9-11ea-8ed4-1a6cae4635cc.png)

## Business / Corporate Websites | Best Web Design 

This is very simple project about Business / Corporate Websites Theme Design:: | HTML5 | CSS3 | JS | Git |

## Deployment

Add additional notes about how to deploy this on a live system

## Built With

* [HTML5](#) 
* [CSS3](#) 
* [JavaScript](#) 
* [Flex Slider](#) 
* [CSS Flexbox](#) 

## Authors

* **Bayes Ahmed Shoharto** - *Initial work* - [shoharto](https://github.com/shoharto/)


## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* I learnt this one from youTube.


